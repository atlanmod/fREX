Before the test cases can be executed, the following steps have to be performed:
* Build moliz-core without aspects: Run ant script build-core-noaspects.xml located in org.modelexecution.fumldebug.core
* Adapt manifest file of project org.modelexecution.fumldebug