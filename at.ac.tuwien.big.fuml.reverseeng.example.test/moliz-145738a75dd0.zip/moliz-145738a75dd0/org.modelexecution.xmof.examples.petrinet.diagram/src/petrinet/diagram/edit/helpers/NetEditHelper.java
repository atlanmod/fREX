package petrinet.diagram.edit.helpers;

/**
 * @generated
 */
public class NetEditHelper extends PetrinetBaseEditHelper {
}
