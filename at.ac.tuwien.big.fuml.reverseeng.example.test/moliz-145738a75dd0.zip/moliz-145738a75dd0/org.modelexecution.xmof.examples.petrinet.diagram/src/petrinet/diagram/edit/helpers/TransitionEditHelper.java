package petrinet.diagram.edit.helpers;

/**
 * @generated
 */
public class TransitionEditHelper extends PetrinetBaseEditHelper {
}
