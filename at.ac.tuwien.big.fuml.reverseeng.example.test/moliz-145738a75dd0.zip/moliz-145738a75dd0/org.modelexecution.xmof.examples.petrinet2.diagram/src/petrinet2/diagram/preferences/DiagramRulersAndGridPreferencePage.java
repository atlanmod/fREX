package petrinet2.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.RulerGridPreferencePage;

import petrinet2.diagram.part.Petrinet2DiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramRulersAndGridPreferencePage extends RulerGridPreferencePage {

	/**
	 * @generated
	 */
	public DiagramRulersAndGridPreferencePage() {
		setPreferenceStore(Petrinet2DiagramEditorPlugin.getInstance()
				.getPreferenceStore());
	}
}
