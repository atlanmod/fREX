package petrinet2.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.ConnectionsPreferencePage;

import petrinet2.diagram.part.Petrinet2DiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramConnectionsPreferencePage extends ConnectionsPreferencePage {

	/**
	 * @generated
	 */
	public DiagramConnectionsPreferencePage() {
		setPreferenceStore(Petrinet2DiagramEditorPlugin.getInstance()
				.getPreferenceStore());
	}
}
