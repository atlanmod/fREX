package petrinet2.diagram.edit.helpers;

/**
 * @generated
 */
public class PlaceEditHelper extends Petrinet2BaseEditHelper {
}
