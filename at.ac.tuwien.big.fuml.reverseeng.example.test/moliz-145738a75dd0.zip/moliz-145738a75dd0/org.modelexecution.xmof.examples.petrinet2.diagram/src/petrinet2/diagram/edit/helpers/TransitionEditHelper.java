package petrinet2.diagram.edit.helpers;

/**
 * @generated
 */
public class TransitionEditHelper extends Petrinet2BaseEditHelper {
}
