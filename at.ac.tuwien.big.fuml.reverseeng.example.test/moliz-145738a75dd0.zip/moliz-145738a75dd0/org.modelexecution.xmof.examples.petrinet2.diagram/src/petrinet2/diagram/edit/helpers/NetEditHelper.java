package petrinet2.diagram.edit.helpers;

/**
 * @generated
 */
public class NetEditHelper extends Petrinet2BaseEditHelper {
}
