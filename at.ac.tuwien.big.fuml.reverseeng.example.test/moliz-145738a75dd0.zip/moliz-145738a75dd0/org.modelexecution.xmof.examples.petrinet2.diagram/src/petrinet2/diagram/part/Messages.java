package petrinet2.diagram.part;

import org.eclipse.osgi.util.NLS;

/**
 * @generated
 */
public class Messages extends NLS {

	/**
	 * @generated
	 */
	static {
		NLS.initializeMessages("messages", Messages.class); //$NON-NLS-1$
	}

	/**
	 * @generated
	 */
	private Messages() {
	}

	/**
	 * @generated
	 */
	public static String Petrinet2CreationWizardTitle;

	/**
	 * @generated
	 */
	public static String Petrinet2CreationWizard_DiagramModelFilePageTitle;

	/**
	 * @generated
	 */
	public static String Petrinet2CreationWizard_DiagramModelFilePageDescription;

	/**
	 * @generated
	 */
	public static String Petrinet2CreationWizard_DomainModelFilePageTitle;

	/**
	 * @generated
	 */
	public static String Petrinet2CreationWizard_DomainModelFilePageDescription;

	/**
	 * @generated
	 */
	public static String Petrinet2CreationWizardOpenEditorError;

	/**
	 * @generated
	 */
	public static String Petrinet2CreationWizardCreationError;

	/**
	 * @generated
	 */
	public static String Petrinet2CreationWizardPageExtensionError;

	/**
	 * @generated
	 */
	public static String Petrinet2DiagramEditorUtil_OpenModelResourceErrorDialogTitle;

	/**
	 * @generated
	 */
	public static String Petrinet2DiagramEditorUtil_OpenModelResourceErrorDialogMessage;

	/**
	 * @generated
	 */
	public static String Petrinet2DiagramEditorUtil_CreateDiagramProgressTask;

	/**
	 * @generated
	 */
	public static String Petrinet2DiagramEditorUtil_CreateDiagramCommandLabel;

	/**
	 * @generated
	 */
	public static String Petrinet2DocumentProvider_isModifiable;

	/**
	 * @generated
	 */
	public static String Petrinet2DocumentProvider_handleElementContentChanged;

	/**
	 * @generated
	 */
	public static String Petrinet2DocumentProvider_IncorrectInputError;

	/**
	 * @generated
	 */
	public static String Petrinet2DocumentProvider_NoDiagramInResourceError;

	/**
	 * @generated
	 */
	public static String Petrinet2DocumentProvider_DiagramLoadingError;

	/**
	 * @generated
	 */
	public static String Petrinet2DocumentProvider_UnsynchronizedFileSaveError;

	/**
	 * @generated
	 */
	public static String Petrinet2DocumentProvider_SaveDiagramTask;

	/**
	 * @generated
	 */
	public static String Petrinet2DocumentProvider_SaveNextResourceTask;

	/**
	 * @generated
	 */
	public static String Petrinet2DocumentProvider_SaveAsOperation;

	/**
	 * @generated
	 */
	public static String InitDiagramFile_ResourceErrorDialogTitle;

	/**
	 * @generated
	 */
	public static String InitDiagramFile_ResourceErrorDialogMessage;

	/**
	 * @generated
	 */
	public static String InitDiagramFile_WizardTitle;

	/**
	 * @generated
	 */
	public static String InitDiagramFile_OpenModelFileDialogTitle;

	/**
	 * @generated
	 */
	public static String Petrinet2NewDiagramFileWizard_CreationPageName;

	/**
	 * @generated
	 */
	public static String Petrinet2NewDiagramFileWizard_CreationPageTitle;

	/**
	 * @generated
	 */
	public static String Petrinet2NewDiagramFileWizard_CreationPageDescription;

	/**
	 * @generated
	 */
	public static String Petrinet2NewDiagramFileWizard_RootSelectionPageName;

	/**
	 * @generated
	 */
	public static String Petrinet2NewDiagramFileWizard_RootSelectionPageTitle;

	/**
	 * @generated
	 */
	public static String Petrinet2NewDiagramFileWizard_RootSelectionPageDescription;

	/**
	 * @generated
	 */
	public static String Petrinet2NewDiagramFileWizard_RootSelectionPageSelectionTitle;

	/**
	 * @generated
	 */
	public static String Petrinet2NewDiagramFileWizard_RootSelectionPageNoSelectionMessage;

	/**
	 * @generated
	 */
	public static String Petrinet2NewDiagramFileWizard_RootSelectionPageInvalidSelectionMessage;

	/**
	 * @generated
	 */
	public static String Petrinet2NewDiagramFileWizard_InitDiagramCommand;

	/**
	 * @generated
	 */
	public static String Petrinet2NewDiagramFileWizard_IncorrectRootError;

	/**
	 * @generated
	 */
	public static String Petrinet2DiagramEditor_SavingDeletedFile;

	/**
	 * @generated
	 */
	public static String Petrinet2DiagramEditor_SaveAsErrorTitle;

	/**
	 * @generated
	 */
	public static String Petrinet2DiagramEditor_SaveAsErrorMessage;

	/**
	 * @generated
	 */
	public static String Petrinet2DiagramEditor_SaveErrorTitle;

	/**
	 * @generated
	 */
	public static String Petrinet2DiagramEditor_SaveErrorMessage;

	/**
	 * @generated
	 */
	public static String Petrinet2ElementChooserDialog_SelectModelElementTitle;

	/**
	 * @generated
	 */
	public static String ModelElementSelectionPageMessage;

	/**
	 * @generated
	 */
	public static String ValidateActionMessage;

	/**
	 * @generated
	 */
	public static String Petrinet21Group_title;

	/**
	 * @generated
	 */
	public static String Place1CreationTool_title;

	/**
	 * @generated
	 */
	public static String Place1CreationTool_desc;

	/**
	 * @generated
	 */
	public static String Transition2CreationTool_title;

	/**
	 * @generated
	 */
	public static String Transition2CreationTool_desc;

	/**
	 * @generated
	 */
	public static String Input3CreationTool_title;

	/**
	 * @generated
	 */
	public static String Input3CreationTool_desc;

	/**
	 * @generated
	 */
	public static String Output4CreationTool_title;

	/**
	 * @generated
	 */
	public static String Output4CreationTool_desc;

	/**
	 * @generated
	 */
	public static String CommandName_OpenDiagram;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Place_2002_incominglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Transition_2001_outgoinglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Net_1000_links;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_TransitionInput_4002_target;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_TransitionInput_4002_source;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_TransitionOutput_4001_target;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_TransitionOutput_4001_source;

	/**
	 * @generated
	 */
	public static String NavigatorActionProvider_OpenDiagramActionName;

	/**
	 * @generated
	 */
	public static String AbstractParser_UnexpectedValueType;

	/**
	 * @generated
	 */
	public static String AbstractParser_WrongStringConversion;

	/**
	 * @generated
	 */
	public static String AbstractParser_UnknownLiteral;

	/**
	 * @generated
	 */
	public static String MessageFormatParser_InvalidInputError;

	/**
	 * @generated
	 */
	public static String Petrinet2ModelingAssistantProviderTitle;

	/**
	 * @generated
	 */
	public static String Petrinet2ModelingAssistantProviderMessage;

	//TODO: put accessor fields manually	
}
