/**
 */
package modeldebuggerconfig.impl;

import modeldebuggerconfig.ModeldebuggerconfigPackage;
import modeldebuggerconfig.StepDefinition;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Step Definition</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public abstract class StepDefinitionImpl extends MinimalEObjectImpl.Container implements StepDefinition {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StepDefinitionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModeldebuggerconfigPackage.Literals.STEP_DEFINITION;
	}

} //StepDefinitionImpl
