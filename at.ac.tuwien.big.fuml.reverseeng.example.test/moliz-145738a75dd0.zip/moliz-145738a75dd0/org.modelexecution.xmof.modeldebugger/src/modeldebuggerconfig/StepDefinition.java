/**
 */
package modeldebuggerconfig;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Step Definition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modeldebuggerconfig.ModeldebuggerconfigPackage#getStepDefinition()
 * @model abstract="true"
 * @generated
 */
public interface StepDefinition extends EObject {
} // StepDefinition
